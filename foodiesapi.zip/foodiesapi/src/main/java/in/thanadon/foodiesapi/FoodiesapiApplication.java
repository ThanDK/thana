package in.thanadon.foodiesapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodiesapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodiesapiApplication.class, args);
	}

}
